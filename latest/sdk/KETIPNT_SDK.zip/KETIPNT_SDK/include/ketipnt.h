
/*//<---------------------------------------------------------------------------->
  ketipntapi.h - KETI PNT API for C-ABI
		- Linux/Windows compatible DLL

  Original Author: Toystar, KETI 
  E-mail		 : toystar@gmail.com
  Date			 : 2022-07-01

*///<---------------------------------------------------------------------------->

/*//<---------------------------------------------------------------------------->

  MODIFICATION LOG - modifiers, enter your name, affiliation, date and
  changes you are making here.

      Name, Affiliation, Date:
  Description of Modification:

*///<---------------------------------------------------------------------------->

/**
  @file ketipntapi.h 
  @brief KETI PNT API for C-ABI
		- Linux/Windows compatible DLL
*/
#pragma once

#if defined(KETIPNT_API_STATIC)			// 1: static building & using
#  define KETIPNT_API
#elif defined(KETIPNT_API_SHARED)		// 2: shared building
#  if defined(_WIN32)
#    define KETIPNT_API __declspec(dllexport)
#  elif defined(__ELF__)
#    define KETIPNT_API __attribute__ ((visibility ("default")))
#  else
#    define KETIPNT_API
#  endif
#else									// 3: shared using (default)
#  if defined(_WIN32)
#    define KETIPNT_API __declspec(dllimport)
#  else
#    define KETIPNT_API
#  endif
#endif


#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>


#ifdef __cplusplus
extern "C" {
#endif

#if (defined _WIN32 || defined _WIN64) && not defined PATH_MAX
#ifndef MAX_PATH
#define MAX_PATH 260
#endif
#define PATH_MAX MAX_PATH
#elif not defined PATH_MAX
#define PATH_MAX FILENAME_MAX
#endif



#define KETIPNT_PATH_MAX (PATH_MAX > 1024 && FILENAME_MAX > 1024 ? 1024 : (PATH_MAX < FILENAME_MAX ? PATH_MAX : FILENAME_MAX))
#define KETIPNT_IP_MAX		16
#define KETIPNT_URL_MAX		256
#define KETIPNT_NAME_MAX	32



#define KETIPNT_USE_SVNAV_DATA	1

#ifdef KETIPNT_DONT_USE_SVNAV_DATA
#undef	KETIPNT_USE_SVNAV_DATA 
#endif

//------------------------------------------------------------------------
//-- PPPRTKRunner
//------------------------------------------------------------------------
typedef enum{
	KETIPNT_SOL_NONE		 		= 0, 			// NOT fixed
	//SOL_SPP_RCV 			= 1,			// SPP             : from RCV
	KETIPNT_SOL_SPP 		 		= 1,			// SPP             : computed approx. Position by SPPSolver
	KETIPNT_SOL_SPP_CORRECTED 		= 2,			// SPP (corrected) : PNTSPPSolver output
	KETIPNT_SOL_PPPRTK_FLOAT 		= 3,			// PPPRTK FLOAT Solution (AR failed)
	KETIPNT_SOL_PPPRTK_FIXED 		= 4,			// PPPRTK FIXED PAR
	KETIPNT_SOL_PPPRTK_FIXED_PAR 	= 4,			// PPPRTK FIXED PAR
	KETIPNT_SOL_PPPRTK_FIXED_FAR	= 5,			// PPPRTK FIXED FAR
	/* .... */
	KETIPNT_SOL_RMODE				=255,			// R-MODE
} ppprtk_solution_quality_t;

typedef struct{
	void* resultPE;
	void* reusltNEQ;

	double xyz[3];							// fixed position in ECEF
	ppprtk_solution_quality_t quality{KETIPNT_SOL_NONE};
	uint32_t epoch;							// GPS epoch used to compute the solution;; TODO: change to the FP
	uint32_t epochSSR;						// SSR epoch used to compute the solution

	// protection level
	double hpl{0};							// HPL
	double vpl{0};							// VPL
	bool integrity{false};					// true: available, false:N/A
} ppprtk_result_t;


/**
 * @brief a opaque structure for PPPRTKRunner
 * 
 */
struct PPPRTKRunner;
typedef PPPRTKRunner ppprtk_runner_t;


typedef struct _ppprtk_runner_option{
	char 		version[KETIPNT_NAME_MAX];				// N/A
	char 		rootpath[KETIPNT_PATH_MAX];				// 프로그램의 루트 경로

	char 		cfg_filename[KETIPNT_PATH_MAX];			// 설정 파일 			

	// (option) MQTT 설정 
	char 		mqtt_broker_ip[KETIPNT_URL_MAX];		// MQTT Broker IP 주소 
	uint16_t 	mqtt_broker_port;						// MQTT Broker 포트 번호 
	char 		mqtt_client_name[KETIPNT_NAME_MAX];		// MQTT Client 이름;설정하지 않을 시, 자동 설정 
	char		mqtt_username[KETIPNT_NAME_MAX];		// (option) MQTT Broker 사용자 이름 
	char 		mqtt_password[KETIPNT_NAME_MAX];		// (option) MQTT Broker 사용자 암호 

	// NTRIP 설정 
	char 		ntrip_caster_ip[KETIPNT_URL_MAX];		// NTRIP Caster IP 주소 
	uint16_t 	ntrip_caster_port;						// NTRIP Caster 포트 번호  
	char 		ntrip_mountpoint[KETIPNT_NAME_MAX];		// NTRIP Caster 마운트포인트 
	char 		ntrip_username[KETIPNT_NAME_MAX];		// NTRIP Caster 사용자 이름 
	char 		ntrip_password[KETIPNT_NAME_MAX];		// NTRIP Caster 사용자 암호 

	// GNSS device 설정: NoVatel OEM7 수신기와 UBlox Zed-F9P 수신기만 지원 
	char 		rcv_device[KETIPNT_NAME_MAX];			// GPS 수신기 설정: ttyXXX or tcp:<ip>:<port> 형식 
	bool 		rcv_ublox;								// GPS 수신기가 UBLOX이면 true

	// Rmode device 설정 
	char 		rmode_device[KETIPNT_NAME_MAX];			// Rmode 디바이스 설정: 지정하지 않으면, 수신플랫폼의 지정된 포트(ttyMAX2)로 설정 

	// MBC DVB/DMB device
	char 		mbc_device[KETIPNT_NAME_MAX];			// MBC SSR 디바이스 설정

	char		output_device[KETIPNT_NAME_MAX];		// 측위 결과를 출력할 포트 설정; 설정하지 않으면 수신플랫폼의 지정된 포트(ttyMAX0)로 설정 
	int 		ifmt_output;							// 출력형식 지정 :  기본값은 0
														//    0: 일반 NMEA GPGGA, 1: SPP결과에 대한 GPGGA, 2: PPPRTK w/ PL 결과에 대한 GPGGA
														//    3: SSRPOS 형식으로 출력, 4: SPP 결과와 PPPRTK 결과 모두 출력, 5: 3과 4의 결합 
	
	unsigned int 	run_time;							// 측위 알고리즘이 실행될 시간을 분단위로 설정;지정하지 않으면 무한 실행 
	
	// solution parameters
	char 		solution_target_name[KETIPNT_NAME_MAX];	// SSRPOS 형식으로 출력 시, 타겟 이름 지
	int 		solution_mode;							// solution algorithm 0: sync, 1:async

	char 		interp_mode;							// Iono/Trop 보간 방식 설정: 기본값은 automatic grid selection
														//    0: 자동 그리드 선택 
														//    1 ~ 9, 'a' ~ 'w': grid id 1 ~ 32 중 하나의 그리드를 지정 
														//    'z' : grid_list 필드에 직접 지정 
	int			grid_list_size;							// interp_mode = 'z'인 경우에만 유요한 값으로 사용자가 직접 입력한 그리드 목록의 크기(최대 8)
	int			grid_list[8]; 							//  사용자가 직접 입력한 그리드 목록 


	char 		ssr_mode;								// SSR mode(h*: hybrid, p: POINT only, m: MBC only)

	double		reference_position[3];					// 참조위치 지정; 참조 위치가 지정되면, 초기 위치를 해당 값으로 설정
														//   또한, 측위 결과를 참조 위치를 기준으로 에러 산출 가능 
	
	// parameters-related to solver
	int			leap;									// leap seconds : TAI-UTC; 기본값은 37
	double 		ut1mutc;								// UT1 - UTC ; 지정하지 않으면 0

	char 		dcb_file_name[KETIPNT_PATH_MAX];		// default: cfgs/P1C1_RINEX.DCB
	char 		atx_file_name[KETIPNT_PATH_MAX];		// default: cfgs/igs14.atx
	char 		ant_name[KETIPNT_NAME_MAX]; 			// 수신 안테나 이름 지정 
	bool		dynamic_positioning;					// 고정 측위할 것인지 움직이며 이동측위를 할 것인지 설정 
	bool		use_kgd2002;							// KGD2002  고정 좌표계 적용 

	// logging options
	char 		logpath[KETIPNT_PATH_MAX];				// 로그파일을 저장할 경로 지정
	char 		logdate[KETIPNT_NAME_MAX];				// 로그파일의 이름에 들어가 현재 data/time의 문자열 지정 
	bool		split_log_by_day;						// 로그파일을 일 단위로 분리된 파일에 저장 

	bool 		redirectio;								// C++ 표준 출력/에러를 파일로 저장 
	bool 		log_output;								// 측위 결과를 GPGGA 형식으로 파일로 저장 
	bool 		log_raw_data;							// GPS로 수신되는 raw 데이터, NTRIP으로 수신한 raw 데이터를 저장 
	bool 		log_result;								// 처리된 결과 데이터를 저장(ephem, pos 등) 
	bool 		log_result_mat;							// 처리된 결과 데이터를 MATLAB mat 파일 형식으로 저장


	bool		verbose;								// 화면에 메시지를 출력할지를 설정 

} ppprtk_runner_options_t;


typedef void(*ppprtk_runner_handler_t)(void*,void*);

/**
 * @brief ppprtk_runner_options_t 구조체를 동적으로 생성하고 기본값으로 설정 후, 포인터를 반환한다. 
 * 		  사용 후에는 반드시 메모리를 해제해야 한다.  
 * 
 * @return ppprtk_runner_options_t* 
 */
KETIPNT_API ppprtk_runner_options_t* ketipnt_ppprtk_runner_create_option();
/**
 * @brief 동적으로 생성된 ppprtk_runner_options_t 구조체 포인터에 대한 메모리 해제를 수행한다. 
 * 
 * @param option 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_runner_create_option_destroy(ppprtk_runner_options_t* option);

/**
 * @brief ppprtk_runner_options_t 구조체를 기본 설정값으로 채운다.
 * 
 * @param option 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_runner_set_default(ppprtk_runner_options_t* option);

/**
 * @brief ppprtk_runner_options_t 구조체의 각 필드들을 화면에 출력한다. 
 * 
 * @param option 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_runner_print(ppprtk_runner_options_t* option);


/**
 * @brief ppprtk_runner_options_t 구조체의 설정 정보를 기반으로 PPPRTKRunner를 위한 ppprtk_runner_t 구조체 포인터를 생성한다. 
 * 
 * @param option 
 * @return ppprtk_runner_t* 
 */
KETIPNT_API ppprtk_runner_t* ketipnt_ppprtk_runner_create(const ppprtk_runner_options_t* option);

/**
 * @brief ppprtk_runner_t 구조체 객체가 정상적으로 생성되었는지 확인한다. 
 * 
 * @param runner 
 * @return bool 	true: 정상, false: 사용불가 
 */
KETIPNT_API bool ketipnt_ppprtk_runner_good(ppprtk_runner_t* runner);

/**
 * @brief 측위결과를 처리할 수 있는 콜백(callback)함수를 지정한다. 
 * 
 * @param runner 		opaque pointer 
 * @param handler 		콜백함수의 함수포인터 
 * @param user_data 	사용자정의 데이터 
 * @return void
 */
KETIPNT_API void ketipnt_ppprtk_runner_set_handler(
		ppprtk_runner_t* runner,
		ppprtk_runner_handler_t handler, 
		void* user_data
);

/**
 * @brief PPPRTKRunner를 동기 모드로 실행한다. 이 함수가 실행되면, 프로그램이 블럭된다. 
 * 
 * @param runner  		opaque pointer 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_runner_loop(ppprtk_runner_t* runner);

/**
 * @brief PPPRTKRunner를 별도의 스레드에서 비동기 모드로 실행한다. 이 함수가 실행되면, 즉시 반환된다. 
 * 
 * @param runner  		opaque pointer 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_runner_start(ppprtk_runner_t* runner);

/**
 * @brief 비동기모드로 실행된 PPPRTKRunner를 종료한다. 
 * 
 * @param runner  		opaque pointer 
 * @return void
 */
KETIPNT_API void ketipnt_ppprtk_runner_stop(ppprtk_runner_t* runner);

/**
 * @brief ppprtk_runner_t 구조체 객체를 메모리 해제한다. 
 * 
 * @param runner  		opaque pointer 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_runner_destroy(ppprtk_runner_t* runner);


//------------------------------------------------------------------------
//-- PPPRTK Solver
//------------------------------------------------------------------------
#define KETIPNT_MAXSAT					32			// consider ONLY GPS
#define KETIPNT_MAXGPS					32
#define KETIPNT_MAXFREQ					2			// L1 and L2 

#define KETIPNT_SOL_SYNC				0
#define KETIPNT_SOL_ASYNC				1
#define KETIPNT_SOL_ASYNC_APPROX		2			// SSR2OSR only

// 기본값 
#define KETIPNT_SOL_INTERP_AUTO			'0'
#define KETIPNT_SOL_INTERP_GRIDLIST		'z'
#define KETIPNT_SOL_LEAP_DEFAULT		37

//-------------- GPS OBS
typedef struct _gps_obs_data{
	// raw GPS time of OBS
	int week;												// GPS week number
	double tow;												// GPS ToW(time of week)

	// NOTE:: index-based
	int nobs;												// 관측 GPS 위성  수 
	int prns[KETIPNT_MAXGPS];								// 관측 GPS 위성의 PRN 목록 

	// L1 and L2
	double pseudo_range[KETIPNT_MAXFREQ][KETIPNT_MAXGPS];	// 각 주파수 별 수신안테나와 위성 사이의 의사 거리(pseudo range)
	double carrier_phase[KETIPNT_MAXFREQ][KETIPNT_MAXGPS];	// 각 주파수 별 수신안테나와 위성 사이의 반송파 위상(carrier phase)
	double cnr[KETIPNT_MAXFREQ][KETIPNT_MAXGPS];			// 각 주파수 별 위성 신호의 수신 CNR
	
	// SV NAVs
#ifdef KETIPNT_USE_SVNAV_DATA	
	int sv_week;											// 위성 정보가 수집된 week unmber
	double sv_tow;											// 위성 정보가 수집된 ToW
	int nsv;												// 위성 정보의 수 
	int sv_prns[KETIPNT_MAXGPS];							// 위성의 수 
	double sv_pos[3*KETIPNT_MAXGPS];						// 위성의 ECEF position [m]
	double sv_clkbias[KETIPNT_MAXGPS];						// 위성 clk bias [m]
	double sv_az[KETIPNT_MAXGPS];							// 위성 azimuth angle [deg]
	double sv_el[KETIPNT_MAXGPS];							// 위성 elevation angle [deg]
	double sv_iono[KETIPNT_MAXGPS];							// 위성의 ionosphere delay [m]
	double sv_trop[KETIPNT_MAXGPS];							// 위성의 troposphere delay [m]
#endif

	// approx. position from the receiver
	bool posvalid;											// 수신기로 부터 획득된 위치가 유효한지 확인 
	double position[3];										// 수신기가 계산한 위치 
	//double geoid_height;									// 

	// alpha and beta
	double ionoparams[8];				// holding the latest params [radians] 

	int leap;							// leap seconds from GNSS
	double utc[4];						// UTC parameters; [utcA0, utcA1, utcTot, utcWNt]
										//  utcA0 : first parameter of UTC polynomial
										//  utcA1 : second parameter of UTC polynomial
										//  utcTot: UTC parameter reference time of week(GPS time)
										//  utcWNt: UTC parameters reference week number(the 8bit WNT field) 

} gps_obs_data_t;

//-------------- Ephemeris
typedef struct _gps_time{
	time_t sec;				// time (s) expressed standard time_t
	double frac;			// fraction of second under 1s
} gps_time_t;

typedef struct _gps_ephemeris{
	
	int prn;			// just use for GPS			
	int sat;            /* 0-based satellite number from PRN and system */

	int iode,iodc;      /* IODE,IODC */
	int sva;            /* SV accuracy (URA index) */
	int svh;            /* SV health (0:ok) */
	int week;           /* GPS/QZS: gps week, GAL: galileo week */
	int code;           /* GPS/QZS: code on L2, GAL/CMP: data sources */
	int flag;           /* GPS/QZS: L2 P data flag, CMP: nav type */

	/* Toe,Toc,T_trans */
	double toe;			// reference time ephemeris, in seconds  
	double toc;			// reference time of clock 
	double ttr; 		// current GPS tow

	// gps_time_t format (NOT USED)
	gps_time_t gtoe,gtoc,gttr; /* Toe,Toc,T_trans */
	
	/* SV orbit parameters */
	/*
		toe,		// reference time ephemeris, in seconds     
		A,			// semi-major axis, in meters
		e,			// satellite eccentricity  
		i0,			// inclination angle at reference time, in radians 
		OMEGA0,		// right ascension at reference time, in radians 
					// (longitude of ascending node of orbit  plane at weekly epoch)
		omega,		// argument of perigee, in radians
		M0,			// mean anomaly at reference time, in  radians      
		OMEGAdot,	// rate of right ascension, in   radians/second
		deltan,		// mean motion difference from computed value, in radians/second 
		idot,		// rate of inclination angle, in radians/second 
		cic,		// amplitude of the cosine harmonic correction term to the angle of inclination, in radians
		cis,		// amplitude of the sine harmonic correction term to the angle of inclination, in radians
		crc,		// amplitude of the cosine harmonic correction term to the orbit radius, in meters
		crs,		// amplitude of the sine harmonic correction  term to the orbit radius, in meters
		cuc,		// amplitude of the cosine harmonic correction term to the argument of latitude, in radians
		cus,		// amplitude of the sine harmonic correction term to the argument of latitude, in radians

		af0,		// SV clock bias
		af1,		// SV clock drift
		af2,		// SV clock drift rate
		tgd,		// group delay in seconds
	*/
	double A,e,i0,OMEGA0,omega,M0,deltan,OMEGAdot,idot;
	double crc,crs,cuc,cus,cic,cis;

	double fit;         		/* fit interval (h) */
	double af0, af1, af2;    	/* SV clock parameters (af0,af1,af2) */
	double tgd[4];      		/* group delay parameters */
								/* GPS/QZS:tgd[0]=TGD */
								/* GAL    :tgd[0]=BGD E5a/E1,tgd[1]=BGD E5b/E1 */
								/* CMP    :tgd[0]=BGD1,tgd[1]=BGD2 */
	double Adot, ndot;   		/* Adot,ndot for CNAV */

	double ura;					// URA std.dev [m]; can be computed by sva (URA index)

} gps_ephemeris_t;


//-------------- POINT SSR
#define KETIPNT_POINT_MAXFREQ				3	
#define KETIPNT_POINT_MAXGRID				32
#define KETIPNT_POINT_MAXSAT				64
#define KETIPNT_POINT_MAXNET				7

#define KETIPNT_POINT_EPOCH_NONE			0xffffffff
#define KETIPNT_POINT_EPOCH_MASK			0x000fffff				// 20bits
#define KETIPNT_POINT_MAX_EPOCH				604799					// 0 ~ 604799

#define KETIPNT_POINT_SSR_MSG_TYPE_TEST		4060
#define KETIPNT_POINT_SSR_MSG_TYPE			4055

typedef enum{
	KETIPNT_SID_GPS_L1_CA=0,
	KETIPNT_SID_GPS_L1_P,
	KETIPNT_SID_GPS_L1_Z,
	// 3 and 4 reserved
	KETIPNT_SID_GPS_L2_CA=5,
	KETIPNT_SID_GPS_L2,
	KETIPNT_SID_GPS_L2_L2C_M,
	KETIPNT_SID_GPS_L2_L2C_L,
	KETIPNT_SID_GPS_L2_L2C_ML,
	KETIPNT_SID_GPS_L2_P,
	KETIPNT_SID_GPS_L2_Z,
	// 12 and 13 reserved
	KETIPNT_SID_GPS_L5_I=14,
	KETIPNT_SID_GPS_L5_Q=15,
	//reserved
} ssr_signal_id_t;


typedef struct{							// 
	ssr_signal_id_t signal_id;			// uint6;
	double code_bias;					// m
	double phase_bias;					// m
} ssr_signal_bias_t;

typedef struct{							// 
	uint32_t grid_id;					// uint6;	1-32
	double stec;						// TECU
}ssr_ionospheric_delay_t;

typedef struct{
	double zhd;							// m	
	double zwd;							// m
}ssr_tropospheric_delay_t;

typedef struct{
	double quality_indicator;			// SIGMA in meter
	double bias;						// BIAS in meter
}ssr_integrity_info_t;

typedef struct{							//  bits
	uint64_t gps_prn_mask;				// bit 64
	uint8_t network_mask;				// bit 7
	uint8_t integrity_flag;				// bit 1; 0:available, 1: Not available

	ssr_integrity_info_t ura[KETIPNT_POINT_MAXSAT];					// URA info for SSR integrity
	ssr_integrity_info_t iono[KETIPNT_POINT_MAXNET][KETIPNT_POINT_MAXSAT];	// Iono info
	ssr_integrity_info_t trop[KETIPNT_POINT_MAXNET];					// Trop info
	
	// additional
	uint32_t nnets;						// num. of networks
	uint32_t nsats;						// num. of satellites
	uint32_t  prn[KETIPNT_POINT_MAXSAT]; 
	uint8_t  network[KETIPNT_POINT_MAXNET]; 
}ssr_integrity_t;


typedef struct{
	int prn;
	int satno;

	// NOTE:: all values are in meter unit

	// :: Orbit correction
	// from sub msg 01 or 03
	uint32_t iode;						// uint8;
	double radial;						//  m
	double along;						//  m
	double cross;						//  m

	// :: Satellite clock bias correction
	// from sub msg 02 or 03
	uint32_t iodc;						// uint10;
	double c0;							//  m
	double c1;							//  m/s
	double c2;							//  m/s^2

	// :: Signal bias correction
	// from sub msg 04
	uint32_t nfreqs{0};					// uint2;
	ssr_signal_bias_t sigbias[KETIPNT_POINT_MAXFREQ];			// L1, L2, L5???; m

	// :: Ionospheric delay correction
	// from sub msg 05
	uint32_t ngrids{0};					// uint6;
	ssr_ionospheric_delay_t stec[KETIPNT_POINT_MAXGRID];		// m
} ssr_t;




typedef struct _ssr_data{
	// POINT messages
	uint32_t 	epoch_time{KETIPNT_POINT_EPOCH_NONE};	// uint20; 	1s
	uint32_t 	update_interval;						// uint4;	1s
	uint32_t 	iod_ssr;								// uint4


	int 	size;
	ssr_t ssrs[KETIPNT_POINT_MAXSAT];					// index-based

	// :: Tropospheric delay correction
	// from sub msg 06: not dependant on sats
	ssr_tropospheric_delay_t tropo_delays[KETIPNT_POINT_MAXGRID];		// NOTE: grid_id 1-based...


	// :: Integrity quality from SMT07
	ssr_integrity_t integrity;

} ssr_data_t;



struct PPPRTKSolver;
typedef PPPRTKSolver ppprtk_solver_t;

// Incomplete data structure in the original codes
struct _gps_data;
typedef _gps_data gps_data_t;

struct _point_data;
typedef _point_data point_data_t;

struct _gnss_ephemeris;
typedef _gnss_ephemeris gnss_ephemeris_t;

/**
 * @brief create an opaque pointer for PPPRTK solver
 * 
 * @param solution_mode 		solution mode: choose one between KETIPNT_SOL_SYNC 
 * 								and KETIPNT_SOL_ASYNC
 * @param interp_mode 			interpolation mode
 * @param dynamic_positioning 	dynamic positioning that update the reference position 
 * 							    with the previous estimated position
 * @param leap 					leap second
 * @param ut1mutc 				UT1-UTC 
 * @param rs_pos 				RS poistion in ECEF
 * @param atx_filename 			.atx file name
 * @param dcb_filename 			.dcb file name
 * @param rcv_ant 				receiver antenna name
 * @param workspace 			worksapce folder
 * @return ppprtk_solver_t* 
 */
KETIPNT_API ppprtk_solver_t* ketipnt_ppprtk_solver_create(
		int solution_mode, 
		char interp_mode,  
		bool dynamic_positioning, 
		bool use_kgd2002,
		int leap, 
		double ut1mutc,
		const double rs_pos[3], 
		const char*atx_filename, 
		const char* dcb_filename, 
		const char* rcv_ant,
		const char* workspace
		);

/**
 * @brief create an opaque pointer for PPPRTK solver with minimal options
 * 
 * @param solution_mode 		solution mode: choose one between KETIPNT_SOL_SYNC 
 * 								and KETIPNT_SOL_ASYNC
 * @param interp_mode 			interpolation mode
 * @param dynamic_positioning 	dynamic positioning that update the reference position 
 * 							    with the previous estimated position
 * @return KETIPNT_API* 
 */
KETIPNT_API ppprtk_solver_t* ketipnt_ppprtk_solver_create_by_minimal(
		int solution_mode, 
		char interp_mode,  
		bool dynamic_positioning,
		bool use_kgd2002);

/**
 * @brief create an opaque pointer for PPPRTK solver with a CFG file
 * 
 * @param cfgfile 				CFG file name
 * @param leap 					leap second
 * @param ut1mutc 				UT1-UTC 
 * @return ppprtk_solver_t* 
 */
KETIPNT_API ppprtk_solver_t* ketipnt_ppprtk_solver_create_by_cfgfile(
		const char* cfgfile, 
		int leap, 
		double ut1mutc);
/**
 * @brief set the GRID list 
 * 
 * @param solver 				an opaque pointer for PPPRTK solver
 * @param list 					a list that includ the grid points from 1 to 32
 * @param size 					the length of the grid list(normaly <=4)
 * @return void
 */
KETIPNT_API void ketipnt_ppprtk_solver_set_gridlist(
		ppprtk_solver_t* solver, 
		int* list, 
		int size);

/**
 * @brief reset the PPPRTK solver
 * 
 * @param solver 				an opaque pointer for PPPRTK solver
 * @param filter_only 			if true, reset the only Kalman filter 
 * 								otherwise reset all objects that have states 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_solver_reset(
		ppprtk_solver_t* solver, 
		bool filter_only);

 
/**
 * @brief add a GPS OBS with incomplete GPS data structure
 * 
 * @param solver 				an opaque pointer for PPPRTK solver
 * @param gps 					add an opaque GPS Observation data to the solver
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_solver_add_obs_opaque(
		ppprtk_solver_t* solver, 
		const gps_data_t* gps);


/**
 * @brief add a GPS OBS with complete/visible data structure
 * 
 * @param solver  				an opaque pointer for PPPRTK solver
 * @param obs 					complete GPS data structure 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_solver_add_obs(
		ppprtk_solver_t* solver, 
		const gps_obs_data_t* obs);


/**
 * @brief add an EPH with incomplete EPH structure
 * 
 * @param solver 		an opaque pointer for PPPRTK solver
 * @param eph 			opaque GPS ephemeris data
 * @return true		 	added successfully
 * @return false		already in the queue
 */
KETIPNT_API bool ketipnt_ppprtk_solver_add_eph_opaque(
		ppprtk_solver_t* solver, 
		const gnss_ephemeris_t* eph);

/**
 * @brief add an EPH with complete/visible data structure
 * 
 * @param solver 		an opaque pointer for PPPRTK solver
 * @param eph 			complete GPS ephemeris data
 * @return true		 	added successfully
 * @return false		already in the queue
 */
KETIPNT_API bool ketipnt_ppprtk_solver_add_eph(
		ppprtk_solver_t* solver, 
		gps_ephemeris_t* eph);


/**
 * @brief add a POINT SSR data with incomplete data structure
 * 
 * @param solver 		an opaque pointer for PPPRTK solver 
 * @param pd 			opaque POINT SSR data structure
 * @return void 		 
 */
KETIPNT_API void ketipnt_ppprtk_solver_add_ssr_opaque(
		ppprtk_solver_t* solver, 
		const point_data_t* pd);

/**
 * @brief add a POINT SSR data with complete/visible data structure
 * 
 * @param solver 		an opaque pointer for PPPRTK solver  
 * @param sd 			complete POINT SSR data structure
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_solver_add_ssr(
		ppprtk_solver_t* solver, 
		ssr_data_t* sd);


/**
 * @brief try to solve the position using GPS OBS and SSR in the queue
 * 
 * @param solver 		an opaque pointer for PPPRTK solver  
 * @return true			position available
 * @return false		no solution
 */
KETIPNT_API bool ketipnt_ppprtk_solver_solve(ppprtk_solver_t* solver);

/**
 * @brief get the result of the position estimation
 * 
 * @param solver  		an opaque pointer for PPPRTK solver 
 * @return ppprtk_result_t* 
 */
KETIPNT_API ppprtk_result_t* ketipnt_ppprtk_solver_get_result(ppprtk_solver_t* solver);

/**
 * @brief destroy the pointer of PPPRTK solver
 * 
 * @param solver   		an opaque pointer for PPPRTK solver 
 * @return void 
 */
KETIPNT_API void ketipnt_ppprtk_solver_destroy(ppprtk_solver_t* solver);

/**
 * @brief get the size of GPS OBS data in the queue
 * 
 * @param solver    		an opaque pointer for PPPRTK solver 
 * @return size_t			num. of GPS OBS data 
 */
KETIPNT_API size_t ketipnt_ppprtk_solver_get_gps_data_buffer_size(ppprtk_solver_t* solver);
/**
 * @brief get the size of POINT SSR data in the queue
 * 
 * @param solver    		an opaque pointer for PPPRTK solver  
 * @return size_t			num. of POINT SSR data 
 */
KETIPNT_API size_t ketipnt_ppprtk_solver_get_point_data_buffer_size(ppprtk_solver_t* solver);

// Utility functions 
// 
/**
 * @brief convert API data structure(gps_obs_data_t) to incomplete/invisible structure(gps_data_t)
 * 
 * @param obs				complete GPS OBS data structure
 * @param gps 				opaque GPS OBS data structure
 * @return void 
 */
KETIPNT_API void ketipnt_convert_obs_to_opaque(
		const gps_obs_data_t* obs, 
		gps_data_t* gps);


/**
 * @brief convert API data structure(ssr_data_t) to incomplete/invisible structure(point_data_t)
 * 
 * @param sd 				complete POINT SSR data structure
 * @param pd 				opaque POINT SSR data structure
 * @return void 
 */
KETIPNT_API void ketipnt_convert_ssr_to_opaque(
		ssr_data_t* sd, 
		point_data_t* pd);

/**
 * @brief convert incomplete/invisible structure(gps_data_t) to API data structure(gps_obs_data_t) 
 * 
 * @param gps 				opaque GPS OBS data structure
 * @param obs 				complete GPS OBS data structure
 * @return void 
 */
KETIPNT_API void ketipnt_convert_obs_from_opaque(
		gps_data_t* gps, 
		gps_obs_data_t* obs);


/**
 * @brief convert incomplete/invisible structure(point_data_t) to API data structure(ssr_data_t)
 * 
 * @param pd 				opaque POINT SSR data structure
 * @param sd 				complete POINT SSR data structure
 * @return void 
 */
KETIPNT_API void ketipnt_convert_ssr_from_opaque(
		point_data_t* pd, 
		ssr_data_t* sd);


// from gps_data_t
/**
 * @brief get TOW of the GPS OBS(PR/CP)
 * 
 * @param gps 				opaque GPS OBS data structure
 * @return double			TOW of the GPS OBS 
 */
KETIPNT_API double ketipnt_get_obs_tow(const gps_data_t* gps);
/**
 * @brief get TOW of the SVs
 * 
 * @param gps 				opaque GPS OBS data structure
 * @return double			TOW of the SVs 
 */
KETIPNT_API double ketipnt_get_sv_tow(const gps_data_t* gps);

/**
 * @brief get the position in ECEF that is estimated by the receiver
 * 
 * @param gps 				opaque GPS OBS data structure 
 * @return const double* 	a pointer of a position vector [x,y,z]
 */
KETIPNT_API const double* ketipnt_get_position(const gps_data_t* gps);
/**
 * @brief 
 * 
 * @param gps 				opaque GPS OBS data structure  
 * @return true				the position is valid 
 * @return false			the position is invalid 
 */
KETIPNT_API bool ketipnt_get_position_vaild(const gps_data_t* gps);

// from point_data_t
/**
 * @brief get the received message(SMT) list of the POINT SSR
 * 
 * @param pd 				opaque POINT SSR data structure
 * @return uint32_t			the received message list 
 */
KETIPNT_API uint32_t ketipnt_get_rcvmsglist(const point_data_t* pd);
/**
 * @brief get the mask fo the received message(SMT) list
 * 
 * @param pd  				opaque POINT SSR data structure
 * @return uint32_t			the mask of the received messages 
 */
KETIPNT_API uint32_t ketipnt_get_rcvmsgmask(const point_data_t* pd);
/**
 * @brief get the epoch time of the POINT SSR
 * 
 * @param pd   				opaque POINT SSR data structure
 * @return uint32_t			epoch time 
 */
KETIPNT_API uint32_t ketipnt_get_epoch(const point_data_t* pd);
/**
 * @brief get the size of SSR data, i.e, the size of PRNs
 * 
 * @param pd   				opaque POINT SSR data structure 
 * @return int 				the size of SSR data
 */
KETIPNT_API int keti_get_ssrlist_size(const point_data_t* pd);

/**
 * @brief get the pointer of the SSR data list
 * 
 * @param pd    			opaque POINT SSR data structure 
 * @return const ssr_t*		the pointer of the SSR  data list	 
 */
KETIPNT_API const ssr_t* keti_get_ssrlist(const point_data_t* pd);


//-------------------

//------------------------------------------------------------------------
//-- SSR2OSRConverter
//------------------------------------------------------------------------
struct SSR2OSRConverter;
typedef SSR2OSRConverter ssr2osr_converter_t;

typedef struct{

	int week;				// week number is adjusted by rollover
	double tow;	

	// RTK rererence station ARP
	uint16_t station_id;
	double ref_position[3]; 


	int nsv{0};
	int prn[KETIPNT_MAXGPS];

	// VRS pesudo-range and carrier-phases
	double l1pr[KETIPNT_MAXGPS];						// L1 pesudo-range 
	double l2pr[KETIPNT_MAXGPS];						// L2 pesudo-range
	double l1cp[KETIPNT_MAXGPS];						// L1 carrier-phase 
	double l2cp[KETIPNT_MAXGPS];						// L2 carrier-phase 

} ssr2osr_result_t;	

/**
 * @brief create an object for SSR2OSR converstion
 * 
 * @param interp_mode 				Iono/Trop Interpolation mode 
 * 										0   : automatic grid selection,
 * 										1 ~ 9: single grid(1 ~ 9 grid id)
 * 										a ~ w: single grid(10 ~ 32 grid id),
 * 											a:10, b:11, c:12, d:13, e:14, f:15, g:16, h:17, i:18, j:19 
 * 											k:20, l:21, m:22, n:23, o:24, p:25, q:26, r: 27, s:28, t:29
 * 											u:30, v:31, w:32
 *										z    : grid list
 * @param relocation_rs_position 	enable/disable the relocation of RS position when too far from the origin RS
 * @param timing_reference 			set the timing reference to convert the SSR to OSR
 * 										g: GPS-based, s: SSR-based, h: SSR-based @ GPS
 * @param leap 						leap seconds
 * @param ut1mutc 					UT1-UTC 
 * @param rs_pos 					initial RS position
 * @param atx_filename 				ATX filename
 * @param rcv_ant 					Receiver antenna name
 * @param rcv_ant 					workspace folder
 * @return ssr2osr_converter_t* 	a converter object created by the function
 */
KETIPNT_API ssr2osr_converter_t* ketipnt_ssr2osr_converter_create(
		char interp_mode,  
		bool relocation_rs_position, 
		char timing_reference, 
		int leap, 
		double ut1mutc,
		const double rs_pos[3], 
		const char*atx_filename, 
		const char* rcv_ant,
		const char* workspace);

/**
 * @brief create an object for SSR2OSR converstion with minimal parameters
 * 
 * @param interp_mode 					Iono/Trop Interpolation mode 
 * 											0   : automatic grid selection,
 * 											1 ~ 9: single grid(1 ~ 9 grid id)
 * 											a ~ w: single grid(10 ~ 32 grid id),
 * 												a:10, b:11, c:12, d:13, e:14, f:15, g:16, h:17, i:18, j:19 
 * 												k:20, l:21, m:22, n:23, o:24, p:25, q:26, r: 27, s:28, t:29
 * 												u:30, v:31, w:32
 *											z    : grid list
 * @param relocation_rs_position 		enable/disable the relocation of RS position when too far from the origin RS
 * @return ssr2osr_converter_t* 	 	a converter object created by the function
 */
KETIPNT_API ssr2osr_converter_t* ketipnt_ssr2osr_converter_create_by_minimal(
		char interp_mode,  
		bool relocation_rs_position);

/**
 * @brief create an object for SSR2OSR converstion from a CFG file
 * 
 * @param cfgfile 						CFG filename
 * @param leap 							leap seconds
 * @param ut1mutc 						UT1-UTC
 * @return ssr2osr_converter_t* 		a converter object created by the function
 */
KETIPNT_API ssr2osr_converter_t* ketipnt_ssr2osr_converter_create_by_cfgfile(
		const char* cfgfile, 
		int leap, 
		double ut1mutc);

/**
 * @brief reset the SSR2OSR converter
 * 
 * @param converter 					opaque pointer for the converter
 * @return void 
 */
KETIPNT_API void ketipnt_ssr2osr_converter_reset(ssr2osr_converter_t* converter);

/**
 * @brief set the RS station ID for RTCM outputs
 * 
 * @param converter 					opaque pointer for the converter
 * @param id 							the RS station ID [0 - 4095]
 * @return void 
 */
KETIPNT_API void ketipnt_ssr2osr_converter_set_station_id(
		ssr2osr_converter_t* converter, 
		int id);

/**
 * @brief set the grid list for Iono/Trop interpolation when interpolation mode is 'z'
 * 
 * @param converter 					opaque pointer for the converter
 * @param list 							grid list in integer values
 * @param size 							the size of the grid list
 * @return void 
 */
KETIPNT_API void ketipnt_ssr2osr_converter_set_gridlist(
		ssr2osr_converter_t* converter, 
		int* list, 
		int size);

/**
 * @brief add a GPS OBS with incomplete GPS data structure
 * 
 * @param converter 					opaque pointer for the converter
 * @param gps							opaque pointer for incomplete GPS OBS data structure
 * @return void 
 */
KETIPNT_API void ketipnt_ssr2osr_converter_add_obs_opaque(
		ssr2osr_converter_t* converter, 
		const gps_data_t* gps);

// add a GPS OBS with complete/visible data structure
/**
 * @brief add a GPS OBS with complete/visible data structure
 * 
 * @param converter 					opaque pointer for the converter
 * @param obs 							a complete GPS OBS data structure
 * @return void 
 */
KETIPNT_API void ketipnt_ssr2osr_converter_add_obs(
		ssr2osr_converter_t* converter, 
		const gps_obs_data_t* obs);


// add an EPH with incomplete EPH structure
//  return :
//		true 	: added successfully
//		false	: already in the queue
/**
 * @brief add an EPH with incomplete EPH structure
 * 
 * @param converter 					opaque pointer for the converter 
 * @param eph 							opaque pointer for the ephemeris data structure
 * @return true 						added successfully,
 * @return false 						already in the queue
 */
KETIPNT_API bool ketipnt_ssr2osr_converter_add_eph_opaque(
		ssr2osr_converter_t* converter, 
		const gnss_ephemeris_t* eph);

// 
/**
 * @brief add an EPH with complete/visible data structure
 * 
 * @param converter 					opaque pointer for the converter 
 * @param eph 							a complete ephemeris data structure
 * @return true 						added successfully,
 * @return false 						already in the queue
 */
KETIPNT_API bool ketipnt_ssr2osr_converter_add_eph(
		ssr2osr_converter_t* converter, 
		gps_ephemeris_t* eph);

/**
 * @brief add a POINT SSR data with incomplete data structure
 * 
 * @param converter 					opaque pointer for the converter  
 * @param pd 							opaque pointer for POINT SSR data structure
 * @return void  
 */
KETIPNT_API void ketipnt_ssr2osr_converter_add_ssr_opaque(
		ssr2osr_converter_t* converter, 
		const point_data_t* pd);


/**
 * @brief add a POINT SSR data with complete/visible data structure
 * 
 * @param converter 					opaque pointer for the converter   
 * @param sd 							a complete POINT SSR data structure
 * @return KETIPNT_API 
 */
KETIPNT_API void ketipnt_ssr2osr_converter_add_ssr(
		ssr2osr_converter_t* converter, 
		ssr_data_t* sd);



/**
 * @brief	convert SSR to OSR
 * 
 * @param converter					opaque pointer for the converter    
 * @return true						OSR converted successfully
 * @return false					no conversion
 */
KETIPNT_API bool ketipnt_ssr2osr_converter_convert(ssr2osr_converter_t* converter);

/**
 * @brief get the result of the conversion
 * 
 * @param converter					opaque pointer for the converter 
 * @return ssr2osr_result_t* 		a pointer to the conversion result
 */
KETIPNT_API ssr2osr_result_t* ketipnt_ssr2osr_converter_get_result(ssr2osr_converter_t* converter);


KETIPNT_API void ketipnt_ssr2osr_converter_copy_result(ssr2osr_converter_t* converter, ssr2osr_result_t* result);

/**
 * @brief destroy the converter object
 * 
 * @param converter 				opaque pointer for the converter 
 * @return void 
 */
KETIPNT_API void ketipnt_ssr2osr_converter_destroy(ssr2osr_converter_t* converter);

/**
 * @brief get the size of the GPS data buffer
 * 
 * @param converter 				opaque pointer for the converter  
 * @return size_t					the size of the buffer 
 */
KETIPNT_API size_t ketipnt_ssr2osr_converter_get_gps_data_buffer_size(ssr2osr_converter_t* converter);
/**
 * @brief get the size of the SSR data buffer
 * 
 * @param converter 				opaque pointer for the converter  
 * @return size_t					the size of the buffer 
 */
KETIPNT_API size_t ketipnt_ssr2osr_converter_get_point_data_buffer_size(ssr2osr_converter_t* converter);

/**
 * @brief get the timing reference
 * 
 * @param converter 				opaque pointer for the converter  
 * @return char						'g':GPS-based, 's':SSR-based, 'h':SSR-based@GPS 
 */
KETIPNT_API char ketipnt_ssr2osr_converter_get_timing_reference(ssr2osr_converter_t* converter);


//------------------------------------------------------------------------
//-- Stream
//------------------------------------------------------------------------
struct Stream;
typedef Stream stream_t;

// create stream
//
//	Serial device: ttyUSB4[:115200:8:n:1:off]
//	TCP device   : tcp:ip:port
//	UDP device   : udp:ip:port
/**
 * @brief create a Serial/TCP/UDP stream
 * 
 * @param device 				device name
 * 									Serial device: ttyUSB4[:115200:8:n:1:off],
 * 									TCP device   : tcp:ip:port,
 * 									UDP device   : udp:ip:port
 * @param nonblocking 			enable/disable non-blocking mode
 * @return stream_t*			a stream object 
 */
KETIPNT_API stream_t* ketipnt_stream_create(
		const char* device, 
		bool nonblocking);

/**
 * @brief open the stream with the device set already in the stream object
 * 		NOTE: only open it when the stream was closed and try to open it with already holding the device name 
 * 
 * @param stream 				opaque pointer for the stream
 * @return true					success,
 * @return false				fail
 */
KETIPNT_API bool ketipnt_stream_open(stream_t *stream);
/**
 * @brief close the stream object that is opened
 * 
 * @param stream 				opaque pointer for the stream
 * @return void 
 */
KETIPNT_API void ketipnt_stream_close(stream_t *stream);
/**
 * @brief get the statu of the stream
 * 
 * @param stream 			 	opaque pointer for the stream
 * @return true					the stream is ok and readable or writable
 * @return false				the stream may be failed
 */
KETIPNT_API bool ketipnt_stream_good(stream_t *stream);

/**
 * @brief destroy the stream object
 * 
 * @param stream 			 	opaque pointer for the stream
 * @return void 
 */
KETIPNT_API void ketipnt_stream_destroy(stream_t *stream);


//------------------------------------------------------------------------
//-- NTRIP
//------------------------------------------------------------------------

struct NanoNTRIP;
typedef NanoNTRIP ntrip_client_t;

typedef struct _ntrip_param{
	char server[KETIPNT_URL_MAX];
	uint16_t port;
	char username[KETIPNT_NAME_MAX];
	char password[KETIPNT_NAME_MAX];
	char mountpoint[KETIPNT_NAME_MAX];				// requested data mount-point

	// proxyserver
	char proxyserver[KETIPNT_URL_MAX];			
	uint16_t proxyport;								// not need to set. internally determined

	// UDP
	uint16_t udpport;								// local udp port for UDP and RTP mode
	int mode;										// auto
	char nmea[128];									// from GPS device	????
	bool initudp;									// send an initial UDP packet in RTP mode

	// flags
	bool printbitrate;
	bool printstdout;

} ntrip_param_t;

typedef  void(*ntrip_client_handler_t)(uint8_t *buf, int nbytes, bool isrtcm, bool fragflag, void *user_data);


KETIPNT_API ntrip_client_t *ketipnt_ntrip_create();
KETIPNT_API void ketipnt_ntrip_set_default(ntrip_param_t* param);
KETIPNT_API void ketipnt_ntrip_set_parameters(
		ntrip_client_t* client, 
		const ntrip_param_t* param);
KETIPNT_API void ketipnt_ntrip_set_parameters_by(
		ntrip_client_t* client, 
		const char *server, 
		uint16_t port,
		const  char *username,
		const  char *password, 
		const  char *mountpoint);

KETIPNT_API void ketipnt_ntrip_set_nmea_gga(
		ntrip_client_t* client, 
		const char* gga);

KETIPNT_API void ketipnt_ntrip_set_output_stream(
		ntrip_client_t* client, 
		stream_t *device);

KETIPNT_API void ketipnt_ntrip_set_handler(
		ntrip_client_t* client, 
		ntrip_client_handler_t handler, 
		void* user_data);

KETIPNT_API void ketipnt_ntrip_loop(ntrip_client_t* client);
KETIPNT_API void ketipnt_ntrip_start(ntrip_client_t* client);
KETIPNT_API void ketipnt_ntrip_stop(ntrip_client_t* client);

KETIPNT_API long ketipnt_ntrip_datarate(
		ntrip_client_t* client, 
		bool clear);

KETIPNT_API void ketipnt_ntrip_destroy(ntrip_client_t* client);



//------------------------------------------------------------------------
//-- RTCM Parser
//------------------------------------------------------------------------
struct NanoRTCM3;
typedef NanoRTCM3 rtcm3_t;

typedef bool(*rtcm3_handler_t)(int type, int staid, void *data, void *opt, void *user_data);

KETIPNT_API rtcm3_t *ketipnt_rtcm3_create(stream_t *stream);
KETIPNT_API void ketipnt_rtcm3_set_stream(
		rtcm3_t* parser, 
		stream_t *stream);

KETIPNT_API void ketipnt_rtcm3_set_handler(
		rtcm3_t* parser, 
		rtcm3_handler_t handler, 
		void *user_data);

KETIPNT_API void ketipnt_rtcm3_loop(rtcm3_t* parser);
KETIPNT_API void ketipnt_rtcm3_start(rtcm3_t* parser);
KETIPNT_API void ketipnt_rtcm3_stop(rtcm3_t* parser);
KETIPNT_API void ketipnt_rtcm3_destroy(rtcm3_t* parser);

//------------------------------------------------------------------------
//-- RTCM Stream Parser
//------------------------------------------------------------------------
struct RTCM3Stream;
typedef RTCM3Stream rtcm3_stream_t;

KETIPNT_API rtcm3_stream_t *ketipnt_rtcm3_stream_create();
KETIPNT_API void ketipnt_rtcm3_stream_set_parser(
		rtcm3_stream_t *stream, 
		rtcm3_t *parser);
KETIPNT_API void  ketipnt_rtcm3_stream_destroy(rtcm3_stream_t *stream);


//------------------------------------------------------------------------
//-- RTCM3 Builder
//------------------------------------------------------------------------
struct NanoRTCM3Builder;
typedef NanoRTCM3Builder rtcm3_builder_t;


KETIPNT_API rtcm3_builder_t *ketipnt_rtcm3_builder_create();
KETIPNT_API void ketipnt_rtcm3_builder_set_output_stream(
		rtcm3_builder_t *builder, 
		stream_t *stream);
KETIPNT_API void ketipnt_rtcm3_builder_reset(rtcm3_builder_t *builder);
KETIPNT_API void ketipnt_rtcm3_builder_build(
		rtcm3_builder_t *builder, 
		int type, 
		ssr2osr_result_t* result);
KETIPNT_API void  ketipnt_rtcm3_builder_destroy(rtcm3_builder_t *builder);


#ifdef INCLUDE_EXTRA
//------------------------------------------------------------------------
//-- NMEA Parser
//------------------------------------------------------------------------
struct NanoNMEA;
typedef NanoNMEA nmea_t;

// system type
typedef enum{
	KETIPNT_NONE=0,
	KETIPNT_GPS,					// GP: GPS only
	KETIPNT_GLONASS,				// GL: GLONASS only
	KETIPNT_GALILEO,				// GA: Galileo only
	KETIPNT_BEIDOU,					// GB/BD: BeiDou Only
	KETIPNT_QZSS,					// GQ: QZSS only
	KETIPNT_NAVIC,					// GI: NavIC only
	KETIPNT_GPS_GLONASS, 			// GN: GPS and GLONASS
} nmea_system_t;

// message type
typedef enum{
	KETIPNT_MSG_EOF=-2,
	KETIPNT_MSG_UNKNOWN=0,
	KETIPNT_MSG_GGA,				// GPS fix data and undulation
	KETIPNT_MSG_GLL,				// Geographic position
	KETIPNT_MSG_GSV,				// GPS satellites in view
	KETIPNT_MSG_GSA,				// GPS DOP and active satellites
	KETIPNT_MSG_GST,				// Estimated error in position solution for GGA
	KETIPNT_MSG_GRS,				// GPS range residuals for each satellite
	KETIPNT_MSG_RMC,				// GPS specific information
} nmea_msg_t;

// GPGGA: GPS fix data and undulation
// This log contains time, position and fix related data of the GNSS receiver
typedef struct {					// GGA data
	double utc;					// UTC time status of position (hours/minutes/seconds/ decimal seconds) hhmmss.ss or hhmmss.sss
	double lat;					// Latitude (DDmm.mm) : 4 fractional precision or  DDmm.mmmm
	char lat_dir;				// Latitude direction (N = North, S = South)
	double lon;					// Longitude (DDDmm.mm) : 4 fractional precision or DDDmm.mmmm	
	char lon_dir;				// Longitude direction (E = East, W = West)
	int quality;				// GPS Quality Indicators
	int nsats;					// Number of satellites in use. May be different to the number in view
	double hdop;				// Horizontal dilution of precision
	double alt;					// Antenna altitude above/below mean sea level
	char alt_units;				// Units of antenna altitude (M = meters)
	double undulation;			// Undulation - the relationship between the geoid and the WGS84 ellipsoid
	char undulation_units;		// Units of undulation (M = meters)
	int age;					// Age of correction data (in seconds), max. 99: it can be empty (max. 99 seconds)
	union{
		int stnId;				// Differential base station ID: it can be empty
		char stnIdStr[4];		
	};		

	// 
	bool dgnss{false};			// true when age and stnId are available
	bool undflag{false};		// true when undulation is available
} nmea_gga_t;

typedef bool(*nmea_handler_t)(int, int, void*, void*);



KETIPNT_API nmea_t* ketipnt_nmea_create();
KETIPNT_API void ketipnt_nmea_set_handler(
		nmea_t* parser, 
		nmea_handler_t handler, 
		void* user_data);
KETIPNT_API void ketipnt_nmea_set_stream(
		nmea_t* parser, 
		stream_t* stream);
KETIPNT_API void ketipnt_nmea_loop(nmea_t* parser);
KETIPNT_API void ketipnt_nmea_start(nmea_t* parser);
KETIPNT_API void ketipnt_nmea_stop(nmea_t* parser);
KETIPNT_API void  ketipnt_nmea_destroy(nmea_t* parser);


KETIPNT_API void ketipnt_nmea_get_lla(
		const nmea_gga_t* gga, 
		double lla[3]);

// return value; utc
KETIPNT_API double ketipnt_nmea_get_gps_time(
		const nmea_gga_t* gga, 
		int* week, 
		double* tow);

#endif

//------------------------------------------------------------------------
//-- NovAtel 
//------------------------------------------------------------------------
struct Novatel;
typedef Novatel novatel_t;

// received novatel messages
#define KETIPNT_RX_NONE					0
#define KETIPNT_RX_RANGE				1
#define KETIPNT_RX_SATXYZ2				2
#define KETIPNT_RX_GPGSV				4
#define KETIPNT_RX_GPSEPHEM				8
#define KETIPNT_RX_IONUTC				16

enum{
	KETIPNT_MSG_EOS 		= -2,			// end-of-stream
	KETIPNT_MSG_ERROR		= -1,			// error
	KETIPNT_MSG_NOERROR		= 0,
	KETIPNT_MSG_OBSDATA,					// OBS data 
	KETIPNT_MSG_EPHEM,						// ephemerids
	KETIPNT_MSG_SATXYZ,						// satellite XYZ
	KETIPNT_MSG_SVINFO, 					// SVINFO
	KETIPNT_MSG_IONUTC, 					// Iono param and UTC
	KETIPNT_MSG_POSXYZ,						// XYZ position
	KETIPNT_MSG_REQALL,						// all required messages are received
	KETIPNT_MSG_NMEA,
	KETIPNT_MSG_RTCM,
	KETIPNT_MSG_NOMOI,						// no message of interest
	
	KETIPNT_MSG_USER=100,					// USER message
};

typedef void(*gnss_handler_t)(int, void *, void *);

KETIPNT_API novatel_t *ketipnt_novatel_create(stream_t *device);

KETIPNT_API void ketipnt_novatel_set_handler(
		novatel_t *receiver, 
		gnss_handler_t handler,
		void *user_data);

KETIPNT_API void ketipnt_novatel_set_required_messages(
		novatel_t *receiver, 
		int list);

KETIPNT_API bool ketipnt_novatel_configure(
		novatel_t* receiver, 
		const char* msg);

KETIPNT_API void ketipnt_novatel_loop(novatel_t* receiver);
KETIPNT_API void ketipnt_novatel_start(novatel_t* receiver);
KETIPNT_API void ketipnt_novatel_stop(novatel_t* receiver);

KETIPNT_API long ketipnt_novatel_datarate(
		novatel_t* receiver, 
		bool clear);

KETIPNT_API void ketipnt_novatel_destroy(novatel_t* receiver);




//------------------------------------------------------------------------
//-- UBlox 
//------------------------------------------------------------------------
struct UBlox;
typedef UBlox ublox_t;

KETIPNT_API ublox_t *ketipnt_ublox_create(stream_t *device);
KETIPNT_API void ketipnt_ublox_set_handler(
		ublox_t *receiver, 
		gnss_handler_t handler,void *user_data);

KETIPNT_API bool ketipnt_ublox_configure(
		ublox_t* receiver, 
		const char* msg);

KETIPNT_API void ketipnt_ublox_loop(ublox_t* receiver);
KETIPNT_API void ketipnt_ublox_start(ublox_t* receiver);
KETIPNT_API void ketipnt_ublox_stop(ublox_t* receiver);

KETIPNT_API long ketipnt_ublox_datarate(
		ublox_t* receiver, 
		bool clear);

KETIPNT_API void ketipnt_ublox_destroy(ublox_t* receiver);


#ifdef INCLUDE_EXTRA
//------------------------------------------------------------------------
//-- UniversalReceiver 
//------------------------------------------------------------------------
struct UniversalReceiver;
typedef UniversalReceiver gnss_receiver_t;

KETIPNT_API gnss_receiver_t *ketipnt_gnss_receiver_create(stream_t *device);
KETIPNT_API void ketipnt_gnss_receiver_set_nmea_parser(
		gnss_receiver_t* receiver, 
		nmea_t* parser);
KETIPNT_API void ketipnt_gnss_receiver_set_rtcm3_parser(
		gnss_receiver_t* receiver, 
		rtcm3_t* parser);
KETIPNT_API void ketipnt_gnss_receiver_loop(gnss_receiver_t* receiver);
KETIPNT_API void ketipnt_gnss_receiver_start(gnss_receiver_t* receiver);
KETIPNT_API void ketipnt_gnss_receiver_stop(gnss_receiver_t* receiver);
KETIPNT_API long ketipnt_gnss_receiver_datarate(
		gnss_receiver_t* receiver, 
		bool clear);
KETIPNT_API void ketipnt_gnss_receiver_destroy(gnss_receiver_t* receiver);
#endif


//------------------------------------------------------------------------
//-- Simple Timer 
//------------------------------------------------------------------------
struct SimpleTimer;
typedef SimpleTimer simple_timer_t;

KETIPNT_API void ketipnt_timer_sleep(long ms);

// unix timestamp in milliseconds
KETIPNT_API double ketipnt_timer_millis();

// unix timestamp in seconds
KETIPNT_API double ketipnt_timer_now();			

KETIPNT_API simple_timer_t* ketipnt_timer_create();
KETIPNT_API double ketipnt_timer_elapsed(simple_timer_t* timer);		// in sec
KETIPNT_API void ketipnt_timer_reset(simple_timer_t* timer);		
KETIPNT_API void ketipnt_timer_destroy(simple_timer_t* timer);		




//------------------------------------------------------------------------
//-- Utilities
//------------------------------------------------------------------------
KETIPNT_API double ketipnt_nan();
KETIPNT_API double ketipnt_inf();
KETIPNT_API double ketipnt_pi();
KETIPNT_API double ketipnt_eps();
KETIPNT_API double ketipnt_deg2rad(double deg);
KETIPNT_API double ketipnt_rad2deg(double rad);

// ECEF XYZ in meter to/from LLA in degree
KETIPNT_API void ketipnt_xyz2lla(
		const double xyz[3], 
		double lla[3]);

KETIPNT_API void ketipnt_lla2xyz(
		const double lla[3], 
		double xyz[3]);

// ECEF XYZ to/from ENU in meter
KETIPNT_API void ketipnt_xyz2enu(
		const double xyz[3], 
		const double ref[3], 
		double enu[3]);

KETIPNT_API void ketipnt_enu2xyz(
		const double enu[3], 
		const double ref[3], 
		double xyz[3]);


#ifdef __cplusplus
}
#endif