
#include <iostream>
#include <cstring>
#include "ketipnt.h"


// NOTE:: lib path: lib/<OS>/<arch>

// 1) 
//    $ g++ api_test.cpp -I../include -lketipnt -lmosquitto -L../lib/Linux/x86_64 -o api_test
//    $ LD_LIBRARY_PATH=../lib/Linux/x86_64 ./api_test
//
//    [POINTer]
//    $ g++ api_test.cpp -I../include -lketipnt -lmosquitto -L../lib/Linux/aarch64 -o api_test
//    $ LD_LIBRARY_PATH=../lib/Linux/aarch64 ./api_test
//
//    [WIN:Mingw] build OK!!
//	  g++ api_test.cpp -I../lib/include -lketipnt -lmosquitto -L../lib/MinGw64/x86_64 -o api_test
//

//    NOTE:: Build with GCC
//    gcc api_test.cpp -I../include -L../lib/ -lketipnt -lmosquitto -o api_test

// 2) static lib linking()
//    $ g++ api_test.cpp -DKETIPNT_API_STATIC  -I../include -l:libketipnt.a -lmosquitto -L../lib/Linux/x86_64  -o api_test
//        or
//    $ g++ api_test.cpp -DKETIPNT_API_STATIC  -I../include -Wl,-Bstatic -lketipnt -Wl,-Bdynamic -lmosquitto -L../lib/Linux/x86_64  -o api_test
//    $./api_test

//   *) libgcc and stdc++ static linking
//    $ g++ api_test.cpp -DKETIPNT_API_STATIC -static-libgcc -static-libstdc++  -I../include -Wl,-Bstatic -lketipnt -Wl,-Bdynamic -lmosquitto -L../Linux/x86_64  -o api_test

//    [WIN:Mingw] build OK !!
//    $g++ api_test.cpp -DKETIPNT_API_STATIC -I../include -Wl,-Bstatic -lketipnt -Wl,-Bdynamic -lmosquitto -lws2_32 -lwinmm -liphlpapi  -L../lib/MinGw64/x86_64 -o api_test
//
//   *) libgcc and stdc++ static linking
//    $ g++ api_test.cpp -DKETIPNT_API_STATIC -static-libgcc -static-libstdc++  -I../include -Wl,-Bstatic -lketipnt -Wl,-Bdynamic -lmosquitto -lws2_32 -lwinmm -liphlpapi  -L../lib/MinGw64/x86_64  -o api_test

// [CHECK] check linked libraries
// 



//----------------------------------------------------------------------
//	PPPRTK runner(All-in-One) test
//----------------------------------------------------------------------
void result_handler(void* param1, void* param2)
{
	ppprtk_runner_t* runner = (ppprtk_runner_t*)param2;
	ppprtk_result_t* result = (ppprtk_result_t*)param1;

	static const char sol_types[6][32]={"None","SPP","C.SPP","PPPRTK-FLOAT","PPPRTK-FIXED-PAR","PPPRTK-FIXED-FAR" };

	if(result->quality!=KETIPNT_SOL_RMODE){
		std::printf("[%lf] RESULT :  %s, x: %lf, y: %lf, z: %lf\n",
					ketipnt_timer_now(),
					sol_types[result->quality],
					result->xyz[0],result->xyz[1],result->xyz[2]);
	}
}

int runner()
{
	
	ppprtk_runner_options_t option;

#if 1
	// :: manual setup

	ketipnt_ppprtk_runner_set_default(&option);

	// rcv setup
	std::strncpy(option.rcv_device,"3001",KETIPNT_NAME_MAX);

	// ntrip setup
	std::strncpy(option.ntrip_username,"point_keti",KETIPNT_NAME_MAX);
	std::strncpy(option.ntrip_password,"ketipoint2022!",KETIPNT_NAME_MAX);

	// verbose off
	option.verbose = false; 

#else
	// :: CFG file
	std::strncpy(option.cfgfile,"test.cfg",KETIPNT_PATH_MAX);
#endif


	// check options
	ketipnt_ppprtk_runner_print(&option);
	
	// create a runner
	ppprtk_runner_t* runner = ketipnt_ppprtk_runner_create(&option);


	if(!ketipnt_ppprtk_runner_good(runner)){
		ketipnt_ppprtk_runner_destroy(runner);
		return -1;
	}

	// add result handler
	ketipnt_ppprtk_runner_set_handler(runner, result_handler, runner);

	ketipnt_ppprtk_runner_loop(runner);				// loop in the blocking mode

	ketipnt_ppprtk_runner_destroy(runner);

	return 0;
}


//----------------------------------------------------------------------
//	NTRIP SSR parsing test
//----------------------------------------------------------------------
struct rtcm3_user_data
{
	rtcm3_t* rtcm3;
	uint32_t epoch_time;
};


bool rtcm3_handler(int type, int staid, void *data, void *opt, void *user_data)
{
	(void)staid;
	(void)opt;
	
	rtcm3_user_data *user =(rtcm3_user_data *)user_data;

	switch(type){
		
		case KETIPNT_POINT_SSR_MSG_TYPE_TEST:   /* fallthrough */
		case KETIPNT_POINT_SSR_MSG_TYPE:{		// POINT SSR
			point_data_t *pd = (point_data_t *)data;	
			int *callopt = (int *)opt;

			// convert point_data_t to visible ssr_data_t;
			ssr_data_t sd;
			ketipnt_convert_ssr_from_opaque(pd, &sd); 


			std::printf("epoch : %d, integrity_flag : %d", sd.epoch_time, sd.integrity.integrity_flag);
			std::printf(", ssr len: %d,  prn: ", sd.size);
			for(int i=0;i<sd.size;i++) std::printf("%d,", sd.ssrs[i].prn);

			if((user->epoch_time!=KETIPNT_POINT_EPOCH_NONE) && user->epoch_time != sd.epoch_time){
				std::printf("  (%d)",(int)sd.epoch_time-(int)user->epoch_time);
			}

			user->epoch_time = (sd.epoch_time+1) & KETIPNT_POINT_EPOCH_MASK;		// next epoch

			if(*callopt == 0) 	std::printf("\n");
			else				std::printf(" (maybe some SMTs are lost)\n");

			//describePointData(pd);

			break;
		}
		default:
			break;
	}

	return true;
}

int ntrip_ssr_test()
{
	// user data
	struct rtcm3_user_data rtcm3user;


	//-----------------------------------------------
	// RTCM3 Parser
	//-----------------------------------------------
	rtcm3user.rtcm3 		= ketipnt_rtcm3_create(nullptr);
	rtcm3user.epoch_time 	= KETIPNT_POINT_EPOCH_NONE;	

	ketipnt_rtcm3_set_handler(rtcm3user.rtcm3, rtcm3_handler, &rtcm3user);		// register handler

	//-----------------------------------------------
	// RTCMStream  setup
	//-----------------------------------------------
	rtcm3_stream_t* rtcmstream = ketipnt_rtcm3_stream_create();
	ketipnt_rtcm3_stream_set_parser(rtcmstream, rtcm3user.rtcm3);

	//-----------------------------------------------
	// NTRIP setup
	//-----------------------------------------------
	ntrip_client_t* client = ketipnt_ntrip_create();

	ntrip_param_t param;
	ketipnt_ntrip_set_default(&param);

	// POINT SSR SERVER
	std::strncpy(param.server,"222.114.162.13",KETIPNT_URL_MAX);
	param.port 			= 2101;
	std::strncpy(param.mountpoint,"POINT-KRISO-RT",KETIPNT_NAME_MAX);
	std::strncpy(param.username,"point_keti",KETIPNT_NAME_MAX);
	std::strncpy(param.password,"ketipoint2022!",KETIPNT_NAME_MAX);

	ketipnt_ntrip_set_parameters(client, &param);		

	// ntrip data to RTCM stream parser	
	ketipnt_ntrip_set_output_stream(client, (stream_t *)rtcmstream);

	std::printf("starting...\n");

	// run in the blocking mode
	ketipnt_ntrip_loop(client);



	// destroy
	ketipnt_ntrip_destroy(client);
	ketipnt_rtcm3_stream_destroy(rtcmstream);
	ketipnt_rtcm3_destroy(rtcm3user.rtcm3);

	return 0;
}

//----------------------------------------------------------------------
//	GPS rcv test
//----------------------------------------------------------------------
struct rcv_userdata{
	novatel_t* receiver;
};

void novatel_handler(int msg, void *data, void* user_data)
{
	rcv_userdata* rcv = (rcv_userdata* )user_data;

	switch(msg){
		case KETIPNT_MSG_OBSDATA:{
			gps_data_t *gps = (gps_data_t *)data;		

			// convert the incomplete gps_data_t to visible gps_obs_data;
			gps_obs_data_t obs;
			ketipnt_convert_obs_from_opaque(gps, &obs);

			std::printf("OBSDATA: tow = %lf, x= %lf, y= %lf, z= %lf\n", 
				obs.tow, obs.position[0],obs.position[1],obs.position[2]);

			break;
		}
		case KETIPNT_MSG_SATXYZ:{
			gps_data_t *gps = (gps_data_t *)data;		

			// convert the incomplete gps_data_t to visible gps_obs_data;
			gps_obs_data_t obs;
			ketipnt_convert_obs_from_opaque(gps, &obs);

			std::printf("SATXYZ: tow = %lf, x= %lf, y= %lf, z= %lf\n", 
				obs.tow, obs.position[0],obs.position[1],obs.position[2]);

			break;
		}
		case KETIPNT_MSG_EPHEM:{
			gnss_ephemeris_t *eph = (gnss_ephemeris_t *)data; 		// incomplete/invisible
			gps_ephemeris_t *geph = (gps_ephemeris_t *)eph;			// renamed

			std::printf("EPHEM: prn=%d, toe = %lf \n", geph->prn, geph->toe);
			
			// add it to solver
		}
		default:
			break;

	}
}

int novatel_test()
{
	stream_t* stream = ketipnt_stream_create("tcp:223.171.145.67:3001",true);		// create a stream with non-blocking

	struct rcv_userdata rcv;
	rcv.receiver = ketipnt_novatel_create(stream);

	// configure
	int msglist = KETIPNT_RX_RANGE|KETIPNT_RX_GPSEPHEM|KETIPNT_RX_SATXYZ2|KETIPNT_RX_IONUTC;
	ketipnt_novatel_set_required_messages(rcv.receiver, msglist);
	ketipnt_novatel_configure(rcv.receiver, nullptr);								// default config
	ketipnt_novatel_configure(rcv.receiver, "log gpsephemb ontime 5\r\n");		// make sure that gpsephem msg must be received
	ketipnt_novatel_set_handler(rcv.receiver, novatel_handler, &rcv);
	
	ketipnt_novatel_loop(rcv.receiver);

	ketipnt_novatel_destroy(rcv.receiver);
	ketipnt_stream_destroy(stream);

	return 0;
}

//----------------------------------------------------------------------
//	PPPRTK solver test
//----------------------------------------------------------------------
struct solver_userdata{
	ppprtk_solver_t* solver;
	
	// POINT SSR parsing
	rtcm3_t* rtcm3;
	rtcm3_stream_t *rtcm3stream;
	ntrip_client_t* client;

	// GPS receiver
	stream_t* stream;
	novatel_t* receiver;

	bool first_fixed;
};

void solve(ppprtk_solver_t* solver)
{

	static const char sol_types[6][32]={"None","SPP","C.SPP","PPPRTK-FLOAT","PPPRTK-FIXED-PAR","PPPRTK-FIXED-FAR" };


	if(ketipnt_ppprtk_solver_solve(solver)){
		ppprtk_result_t* result = ketipnt_ppprtk_solver_get_result(solver);

		if(result->quality!=KETIPNT_SOL_RMODE){
			std::printf("RESULT :  %s, x: %lf, y: %lf, z: %lf\n",
						sol_types[result->quality],
						result->xyz[0],result->xyz[1],result->xyz[2]);
		}	
	}else{
		std::printf("NO solution !!\n");
	}
}

bool ssr_handler(int type, int staid, void *data, void *opt, void *user_data)
{
	(void)staid;
	(void)opt;
	
	solver_userdata *user =(solver_userdata *)user_data;

	switch(type){
		
		case KETIPNT_POINT_SSR_MSG_TYPE_TEST:   /* fallthrough */
		case KETIPNT_POINT_SSR_MSG_TYPE:{		// POINT SSR
			point_data_t *pd = (point_data_t *)data;	
			int *callopt = (int *)opt;

			
			if(*callopt == 0){
				// add POINT SSR to solver 
				ketipnt_ppprtk_solver_add_ssr_opaque(user->solver,pd);
			}else				
				std::printf(" (maybe some SMTs are lost)\n");

			break;
		}
		default:
			break;
	}

	return true;
}

void rcv_handler(int msg, void *data, void* user_data)
{
	solver_userdata* user = (solver_userdata* )user_data;

	switch(msg){
		case KETIPNT_MSG_OBSDATA:{
			gps_data_t *gps = (gps_data_t *)data;		
			double obs_tow = ketipnt_get_obs_tow(gps);
			double sv_tow = ketipnt_get_sv_tow(gps);

			if(obs_tow == sv_tow){
				ketipnt_ppprtk_solver_add_obs_opaque(user->solver, gps);

				solve(user->solver);

				if(	ketipnt_ppprtk_solver_get_gps_data_buffer_size(user->solver)>0 && 
					ketipnt_ppprtk_solver_get_point_data_buffer_size(user->solver)>0){
					solve(user->solver);
				}

				if(!user->first_fixed && ketipnt_ppprtk_solver_get_result(user->solver)->quality >= KETIPNT_SOL_PPPRTK_FLOAT){
					ketipnt_novatel_configure(user->receiver,"log gpsephemb onchanged\r\n");
					user->first_fixed = true;
				}

			}
	
			break;
		}
		case KETIPNT_MSG_SATXYZ:{
			gps_data_t *gps = (gps_data_t *)data;		
			double obs_tow = ketipnt_get_obs_tow(gps);
			double sv_tow = ketipnt_get_sv_tow(gps);

			if(obs_tow<0.){
				std::printf("RANGE log not received: obs time: %lf, sv time: %lf\n", obs_tow, sv_tow);
			}

			if(obs_tow == sv_tow){
				ketipnt_ppprtk_solver_add_obs_opaque(user->solver, gps);

				solve(user->solver);

				if(	ketipnt_ppprtk_solver_get_gps_data_buffer_size(user->solver)>0 && 
					ketipnt_ppprtk_solver_get_point_data_buffer_size(user->solver)>0){
					solve(user->solver);
				}

				if(!user->first_fixed && ketipnt_ppprtk_solver_get_result(user->solver)->quality >= KETIPNT_SOL_PPPRTK_FLOAT){
					ketipnt_novatel_configure(user->receiver,"log gpsephemb onchanged\r\n");
					user->first_fixed = true;
				}

			}
		
			break;
		}
		case KETIPNT_MSG_EPHEM:{
			gnss_ephemeris_t *eph = (gnss_ephemeris_t *)data; 

			ketipnt_ppprtk_solver_add_eph_opaque(user->solver,eph);
		}
		default:
			break;

	}
}


void ntrip_ssr_setup(solver_userdata* user)
{
	//-----------------------------------------------
	// RTCM3 Parser
	//-----------------------------------------------
	user->rtcm3 		= ketipnt_rtcm3_create(nullptr);

	ketipnt_rtcm3_set_handler(user->rtcm3, ssr_handler, user);		// register handler

	//-----------------------------------------------
	// RTCMStream  setup
	//-----------------------------------------------
	user->rtcm3stream = ketipnt_rtcm3_stream_create();
	ketipnt_rtcm3_stream_set_parser(user->rtcm3stream, user->rtcm3);

	//-----------------------------------------------
	// NTRIP setup
	//-----------------------------------------------
	user->client = ketipnt_ntrip_create();

	ntrip_param_t param;
	ketipnt_ntrip_set_default(&param);

	// POINT SSR SERVER
	std::strncpy(param.server,"222.114.162.13",KETIPNT_URL_MAX);
	param.port 			= 2101;
	std::strncpy(param.mountpoint,"POINT-KRISO-RT",KETIPNT_NAME_MAX);
	std::strncpy(param.username,"point_keti",KETIPNT_NAME_MAX);
	std::strncpy(param.password,"ketipoint2022!",KETIPNT_NAME_MAX);

	ketipnt_ntrip_set_parameters(user->client, &param);		

	// ntrip data to RTCM stream parser	
	ketipnt_ntrip_set_output_stream(user->client, (stream_t *)user->rtcm3stream);

}

void gps_rcv_setup(solver_userdata* user, const char* device)
{
	//-----------------------------------------------
	// Novatel Receiver 
	//-----------------------------------------------
	user->stream = ketipnt_stream_create(device,true);		// create a stream with non-blocking
	user->receiver = ketipnt_novatel_create(user->stream);

	// configure
	int msglist = KETIPNT_RX_RANGE|KETIPNT_RX_GPSEPHEM|KETIPNT_RX_SATXYZ2|KETIPNT_RX_IONUTC;
	ketipnt_novatel_set_required_messages(user->receiver, msglist);
	ketipnt_novatel_configure(user->receiver, nullptr);								// default config
	ketipnt_novatel_configure(user->receiver, "log gpsephemb ontime 5\r\n");		// make sure that gpsephem msg must be received
	ketipnt_novatel_set_handler(user->receiver, rcv_handler, user);
}


void destroy(solver_userdata* user)
{
	ketipnt_novatel_destroy(user->receiver);
	ketipnt_stream_destroy(user->stream);

	ketipnt_ntrip_destroy(user->client);
	ketipnt_rtcm3_stream_destroy(user->rtcm3stream);
	ketipnt_rtcm3_destroy(user->rtcm3);
	ketipnt_ppprtk_solver_destroy(user->solver);
}

int solver_test()
{

	struct solver_userdata user;

	user.solver = ketipnt_ppprtk_solver_create_by_minimal(
		KETIPNT_SOL_ASYNC,
		KETIPNT_SOL_INTERP_AUTO,
		false,						// static positioning
		false						// use KGD2002
	);

	user.first_fixed = false;

	ntrip_ssr_setup(&user);
	gps_rcv_setup(&user,"tcp:223.171.145.67:3001");

	ketipnt_ntrip_start(user.client);
	ketipnt_novatel_start(user.receiver);

	double next = ketipnt_timer_now() + 5.;
	while(true){
		double t = ketipnt_timer_now();
		if(t>next){
			next += 5.;

			long dr_gps 	= ketipnt_novatel_datarate(user.receiver, true);
			long dr_ntrip	= ketipnt_ntrip_datarate(user.client, true);

			if(dr_gps==0. || dr_ntrip==0.){
				std::printf("ERROR: GPS DR: %ld, NTRIP DR: %ld\n",dr_gps, dr_ntrip);
			}

		}else{

			ketipnt_timer_sleep((next-t)*1000);
		}

		
	}

	ketipnt_novatel_stop(user.receiver);
	ketipnt_ntrip_stop(user.client);

	// destroy
	destroy(&user);

	return 0;
}

//----------------------------------------------------------------------
//	POINT2RTK converter test
//----------------------------------------------------------------------
struct converter_userdata{
	ssr2osr_converter_t* converter;
	
	// POINT SSR parsing
	rtcm3_t* rtcm3;
	rtcm3_stream_t *rtcm3stream;
	ntrip_client_t* client;

	// GPS receiver
	stream_t* stream;
	ublox_t* receiver;

	//RTCM3 builder
	rtcm3_builder_t* builder;
	stream_t*	osr_stream;
};


void convert(converter_userdata* user)
{
	static bool osr_done = false;

	if(ketipnt_ssr2osr_converter_convert(user->converter)){
		ssr2osr_result_t* result = ketipnt_ssr2osr_converter_get_result(user->converter);

		if(result->nsv==0) return;

		if(!osr_done){
			osr_done = true;
			std::printf("ssr2osr::main::solve:: SSR2OSR conversion OK, nsv =  %d\n",result->nsv);
		}

		// RTCM3 message generation and send to the OSR receiver
		ketipnt_rtcm3_builder_build(user->builder, 1005, result);		// RTK reference station ARP

		//ketipnt_rtcm3_builder_build(user->builder,1074, result);		// GPS MSM4
		ketipnt_rtcm3_builder_build(user->builder, 1075, result);			// GPS MSM5

		std::printf("[%lf] nsv: %d\n", ketipnt_timer_now(),result->nsv);
		for(int i=0;i<result->nsv;i++){
			const auto satno =result->prn[i]-1;
			std::printf("   prn: %d, l1pr= %lf, l1cp=%lf, l2pr= %lf, l2cp= %lf\n",
				satno+1, result->l1pr[satno], result->l1cp[satno], result->l2pr[satno],result->l2cp[satno] 
			);
		}


	}else{
		std::printf("NO solution !!\n");
	}
}

bool s2o_ssr_handler(int type, int staid, void *data, void *opt, void *user_data)
{
	(void)staid;
	(void)opt;
	
	converter_userdata *user =(converter_userdata *)user_data;

	switch(type){
		
		case KETIPNT_POINT_SSR_MSG_TYPE_TEST:   /* fallthrough */
		case KETIPNT_POINT_SSR_MSG_TYPE:{		// POINT SSR
			point_data_t *pd = (point_data_t *)data;	
			int *callopt = (int *)opt;

			
			if(*callopt == 0){
				// add POINT SSR to solver 
				ketipnt_ssr2osr_converter_add_ssr_opaque(user->converter, pd);

				const char tr = ketipnt_ssr2osr_converter_get_timing_reference(user->converter);
				if(tr == 's'){
					convert(user);

					if(	ketipnt_ssr2osr_converter_get_gps_data_buffer_size(user->converter)>0 && 
						ketipnt_ssr2osr_converter_get_point_data_buffer_size(user->converter)>0){
						convert(user);
					}
				}
			}else				
				std::printf(" (maybe some SMTs are lost)\n");

			break;
		}
		default:
			break;
	}

	return true;
}

void s2o_rcv_handler(int msg, void *data, void* user_data)
{
	converter_userdata* user = (converter_userdata* )user_data;

	switch(msg){
		case KETIPNT_MSG_POSXYZ:{
			gps_data_t *gps = (gps_data_t *)data;		
			
			ketipnt_ssr2osr_converter_add_obs_opaque(user->converter, gps);

			const char tr = ketipnt_ssr2osr_converter_get_timing_reference(user->converter);
			if(tr == 'g' || tr == 'h'){
				convert(user);

				if(	ketipnt_ssr2osr_converter_get_gps_data_buffer_size(user->converter)>0 && 
					ketipnt_ssr2osr_converter_get_point_data_buffer_size(user->converter)>0){
					convert(user);
				}
			}

			break;
		}
		case KETIPNT_MSG_EPHEM:{
			gnss_ephemeris_t *eph = (gnss_ephemeris_t *)data; 

			ketipnt_ssr2osr_converter_add_eph_opaque(user->converter,eph);
		}
		default:
			break;

	}
}


void s2o_ntrip_ssr_setup(converter_userdata* user)
{
	//-----------------------------------------------
	// RTCM3 Parser
	//-----------------------------------------------
	user->rtcm3 		= ketipnt_rtcm3_create(nullptr);

	ketipnt_rtcm3_set_handler(user->rtcm3, s2o_ssr_handler, user);		// register handler

	//-----------------------------------------------
	// RTCMStream  setup
	//-----------------------------------------------
	user->rtcm3stream = ketipnt_rtcm3_stream_create();
	ketipnt_rtcm3_stream_set_parser(user->rtcm3stream, user->rtcm3);

	//-----------------------------------------------
	// NTRIP setup
	//-----------------------------------------------
	user->client = ketipnt_ntrip_create();

	ntrip_param_t param;
	ketipnt_ntrip_set_default(&param);

	// POINT SSR SERVER
	std::strncpy(param.server,"222.114.162.13",KETIPNT_URL_MAX);
	param.port 			= 2101;
	std::strncpy(param.mountpoint,"POINT-KRISO-RT",KETIPNT_NAME_MAX);
	std::strncpy(param.username,"point_keti",KETIPNT_NAME_MAX);
	std::strncpy(param.password,"ketipoint2022!",KETIPNT_NAME_MAX);

	ketipnt_ntrip_set_parameters(user->client, &param);		

	// ntrip data to RTCM stream parser	
	ketipnt_ntrip_set_output_stream(user->client, (stream_t *)user->rtcm3stream);




}

void s2o_gps_rcv_setup(converter_userdata* user, const char* device)
{
	//-----------------------------------------------
	// UBlox Receiver 
	//-----------------------------------------------
	user->stream = ketipnt_stream_create(device,true);		// create a stream with non-blocking
	user->receiver = ketipnt_ublox_create(user->stream);

	ketipnt_ublox_set_handler(user->receiver, s2o_rcv_handler, user);
}

void s2o_rtcm_builder_setup(converter_userdata* user, const char* device, bool use_gps_device)
{

	//-----------------------------------------------
	// RTCM3 builder
	//-----------------------------------------------
	user->builder = ketipnt_rtcm3_builder_create();

	user->osr_stream =nullptr;
	if(device!=nullptr && !use_gps_device){
		user->osr_stream = ketipnt_stream_create(device,true);		// create a stream with non-blocking
	}else if(use_gps_device){
		user->osr_stream = user->stream;
	}

	if(user->osr_stream) 
		ketipnt_rtcm3_builder_set_output_stream(user->builder, user->osr_stream);
}


void s2o_destroy(converter_userdata* user)
{
	ketipnt_ublox_destroy(user->receiver);
	if(user->osr_stream==user->stream){
		ketipnt_stream_destroy(user->stream);
	}else{
		ketipnt_stream_destroy(user->stream);
		ketipnt_stream_destroy(user->osr_stream);
	}

	ketipnt_ntrip_destroy(user->client);
	ketipnt_rtcm3_stream_destroy(user->rtcm3stream);
	ketipnt_rtcm3_destroy(user->rtcm3);
	ketipnt_ssr2osr_converter_destroy(user->converter);

	ketipnt_rtcm3_builder_destroy(user->builder);
}

int ssr2osr_test()
{
	struct converter_userdata user;

	user.converter = ketipnt_ssr2osr_converter_create_by_minimal(
		KETIPNT_SOL_INTERP_AUTO,			// grid automatic selection for Iono/Trop interpolation
		true								// RS relocation enabled
	);


	//const char* device = "ttyAMA0";
	const char* device = "tcp:192.168.0.174:6001";
	const char* osr_device = "";						// just test

	bool use_gps_device = osr_device==nullptr || osr_device[0]=='\0' 
						 ||  std::strcmp(device,osr_device)==0 ;

	s2o_ntrip_ssr_setup(&user);
	s2o_gps_rcv_setup(&user, device);
	s2o_rtcm_builder_setup(&user, osr_device, use_gps_device);

	if(!ketipnt_stream_good(user.stream)){
		std::printf("GPS receiver is not avaialble... exit\n");
		s2o_destroy(&user);
		return -1;
	}


	ketipnt_ntrip_start(user.client);
	ketipnt_ublox_start(user.receiver);

	double next = ketipnt_timer_now() + 5.;
	while(true){
		double t = ketipnt_timer_now();
		if(t>next){
			next += 5.;

			long dr_gps 	= ketipnt_ublox_datarate(user.receiver, true);
			long dr_ntrip	= ketipnt_ntrip_datarate(user.client, true);

			if(dr_gps==0. || dr_ntrip==0.){
				std::printf("ERROR: GPS DR: %ld, NTRIP DR: %ld\n",dr_gps, dr_ntrip);
			}

		}else{

			ketipnt_timer_sleep((next-t)*1000);
		}

		
	}

	ketipnt_ublox_stop(user.receiver);
	ketipnt_ntrip_stop(user.client);

	// destroy
	s2o_destroy(&user);

	return 0;
}


void usage(char *program)
{
	std::fprintf(stderr, "\n"
			"usage: %s [h] [options]"
			"\n"
			"options:\n"
			"    h  show this message\n"
			"    r  execute ppprtk runner test\n"
			"    p  execute ntrip point ssr test\n"
			"    n  execute novatel test\n"
			"    s  execute solver test\n"
			"    c  execute ssr2osr test\n"
			"\n" "\n", program);
		std::exit(1);
}

int main(int argc, char *argv[])
{
	if(argc !=2 || argv[1][0]=='h'){
		usage(argv[0]);
		return 0;
	}

	if(argv[1][0]=='r')	return runner();
	if(argv[1][0]=='p')	return ntrip_ssr_test();
	if(argv[1][0]=='n')	return novatel_test();
	if(argv[1][0]=='s')	return solver_test();
	if(argv[1][0]=='c')	return ssr2osr_test();

	std::fprintf(stderr,"not valid option\n");
	usage(argv[0]);
	return 0;
}